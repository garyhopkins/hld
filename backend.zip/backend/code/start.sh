#!/bin/bash

python3 manage.py runserver 0:8080
