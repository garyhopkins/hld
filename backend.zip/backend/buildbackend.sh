#!/bin/bash
docker build -t hldbackend .
